//
//  ViewController.swift
//  izf0002asn2bii
//
//  Created by Ian Fair on 6/28/20.
//  Copyright © 2020 Ian Fair. All rights reserved.
//


import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view, typically from a nib.
       }


    @IBOutlet weak var prinple: UITextField!
    @IBOutlet weak var numOfPayments: UITextField!
    @IBOutlet weak var interestRate: UITextField!
    @IBOutlet weak var result: UITextField!
    @IBAction func calculate(_ sender: Any) {
        
        if numOfPayments.text == "" || prinple.text == "" || interestRate.text == "" {
            result.text = "result error"
            return
        }
        
        let payments = Double(numOfPayments.text!)!
        let rate = Double(interestRate.text!)!
        let principal = Double(prinple.text!)!
        
        let resultFromCalc = paymentCalculator(payments, rate, principal)
        
        result.text = "$ " + resultFromCalc
    }

    func paymentCalculator(_ months: Double, _ apr: Double, _ principle: Double)-> String {
        var payment = 0.0
        payment = (apr / 100 * principle) / (1 - pow((1 + (apr / 100)), (-1 * months)))
        
        return "\(round(100*payment)/100)"
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask(rawValue: (UIInterfaceOrientationMask.portrait.rawValue | UIInterfaceOrientationMask.landscapeLeft.rawValue | UIInterfaceOrientationMask.landscapeRight.rawValue))
    }
}

