//
//  ViewController.swift
//  buttonproject
//
//  Created by Ian Fair on 6/7/20.
//  Copyright © 2020 Ian Fair. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageview: UIImageView!
    
    @IBAction func WarEagle(_ sender: UIButton) {
        imageview.image = UIImage(named: "auburnlogo")
        
    }
    @IBAction func SEC(_ sender: UIButton) {
        imageview.image = UIImage(named: "sec")
        
    }
    @IBAction func Rolltide(_ sender: Any) {
        imageview.image = UIImage(named: "alabama")
        
    }
    
    override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
       }

}




