//
//  ViewController.swift
//  izf0002assignment1c
//
//  Created by Ian Fair on 6/11/20.
//  Copyright © 2020 Ian Fair. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   // override func viewDidLoad() {
       // super.viewDidLoad()
        // Do any additional setup after loading the view.
    //}
    @IBOutlet weak var imagedisp: UIImageView! // first image
        
    @IBOutlet weak var imagedisp2: UIImageView!//second image
    @IBAction func slider(_ sender: UISlider) {
        imagedisp.image = UIImage(named: "Elephant")
        imagedisp.alpha = CGFloat(sender.value)
        imagedisp2.image = UIImage(named: "Auburn")
        imagedisp2.alpha = 1 - CGFloat(sender.value)
        
        
    }
    @IBOutlet weak var AU: UILabel!
    
    @IBOutlet weak var UA: UILabel!
}

