//
//  ViewController.swift
//  izf0002as3a
//
//  Created by Ian Fair on 7/12/20.
//  Copyright © 2020 Ian Fair. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        picker.delegate = self as? UIPickerViewDelegate
        picker.dataSource = self as? UIPickerViewDataSource
        
        pickerData = ["Thing One", "Thing Two", "Thing Three"]
        
    }

   

        @IBOutlet weak var userInput: UITextField!
          @IBOutlet weak var picker: UIPickerView!
          @IBAction func selectButton(_ sender: Any) {
              let row = picker.selectedRow(inComponent: 0)
            
              let selected = pickerData[row]
            
              let title = "You selected \(selected)!"
              let alert = UIAlertController( title: title, message: "Thank you for choosing",preferredStyle: .alert)
              let action = UIAlertAction( title: "You're welcome", style: .default, handler: nil)
              alert.addAction(action)
              present(alert, animated: true, completion: nil)
          }
          @IBAction func replaceButton(_ sender: Any) {
              let row = picker.selectedRow(inComponent: 0)
              if (userInput.text != "") {
                  pickerData[row] = userInput.text!
              }
              picker.reloadAllComponents()
          }
          @IBAction func insertButton(_ sender: Any) {
              let newRow = picker.selectedRow(inComponent: 0) + 1
              if (userInput.text != "") {
                  pickerData.insert(userInput.text!, at: newRow)
              }
            
              picker.reloadAllComponents()
            
              picker.selectRow(newRow, inComponent: 0, animated: true)
          }
          
          
          var pickerData: [String] = [String]()
          
        override func didReceiveMemoryWarning() {
              super.didReceiveMemoryWarning()
              
          }

          func numberOfComponents(in pickerView: UIPickerView) -> Int {
              return 1
          }
          
          func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
              return pickerData.count
          }
          
          func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
              return pickerData[row]
          }

    }


